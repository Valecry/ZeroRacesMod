package org.example.com.zeroraces.registry;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.example.com.zeroraces.ZeroRaces;

import java.util.function.Supplier;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ZeroRaces.MODID);

    // FIXED HELPER METHOD:
    // Changed parameter from 'RegistryObject<? extends EntityType<?>>'
    // to 'Supplier<? extends EntityType<? extends Mob>>'
    // This satisfies the generic constraints of ForgeSpawnEggItem.
    private static RegistryObject<Item> registerEgg(String name, Supplier<? extends EntityType<? extends Mob>> entity, int primaryColor, int secondaryColor) {
        return ITEMS.register(name, () -> new ForgeSpawnEggItem(entity, primaryColor, secondaryColor, new Item.Properties()));
    }

    // --- Spawn Eggs ---
    public static final RegistryObject<Item> HUMAN_SPAWN_EGG = registerEgg("human_spawn_egg", ModEntities.HUMAN, 0xBB8866, 0x334455);
    public static final RegistryObject<Item> ELF_SPAWN_EGG = registerEgg("elf_spawn_egg", ModEntities.ELF, 0xF8E8C0, 0x228822);
    public static final RegistryObject<Item> DWARF_SPAWN_EGG = registerEgg("dwarf_spawn_egg", ModEntities.DWARF, 0xAA6633, 0x553311);
    public static final RegistryObject<Item> KOBOLD_SPAWN_EGG = registerEgg("kobold_spawn_egg", ModEntities.KOBOLD, 0x552200, 0x996633);
    public static final RegistryObject<Item> DRAGONKIN_SPAWN_EGG = registerEgg("dragonkin_spawn_egg", ModEntities.DRAGONKIN, 0x882222, 0xDD9911);
    public static final RegistryObject<Item> BEASTFOLK_SPAWN_EGG = registerEgg("beastfolk_spawn_egg", ModEntities.BEASTFOLK, 0x664422, 0x222222);
    public static final RegistryObject<Item> DEMON_SPAWN_EGG = registerEgg("demon_spawn_egg", ModEntities.DEMON, 0x440000, 0x000000);

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}