package org.example.com.zeroraces.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.AABB;
import org.example.com.zeroraces.Config;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class RaceEntity extends PathfinderMob implements RangedAttackMob {
    private static final EntityDataAccessor<String> DATA_RACE = SynchedEntityData.defineId(RaceEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> DATA_JOB = SynchedEntityData.defineId(RaceEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> DATA_SKIN_ID = SynchedEntityData.defineId(RaceEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<String> DATA_TRAITS = SynchedEntityData.defineId(RaceEntity.class, EntityDataSerializers.STRING);

    // Hidden inventory slot for the sheathed weapon
    private ItemStack storedWeapon = ItemStack.EMPTY;

    public RaceEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setCanPickUpLoot(true);
    }

    // Required for ZeroRaces.java registration
    public static boolean checkRaceSpawnRules(EntityType<RaceEntity> entityType, ServerLevelAccessor level, MobSpawnType spawnType, BlockPos pos, RandomSource random) {
        return checkMobSpawnRules(entityType, level, spawnType, pos, random);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.23)
                .add(Attributes.ATTACK_DAMAGE, 3.0)
                .add(Attributes.FOLLOW_RANGE, 35.0)
                .add(Attributes.SCALE, 1.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_RACE, RaceType.HUMAN.getSerializedName());
        builder.define(DATA_JOB, JobType.CIVILIAN.name());
        builder.define(DATA_SKIN_ID, 1);
        builder.define(DATA_TRAITS, "");
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));

        // 1. PANIC Logic
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4) {
            @Override
            public boolean canUse() {
                float threshold = getJob() == JobType.BANDIT ? 0.15f : 0.30f;
                return super.canUse() && (getHealth() / getMaxHealth()) < threshold;
            }
        });

        // 2. RANGED ATTACK (Bows)
        // Only works if holding a bow
        this.goalSelector.addGoal(2, new RangedBowAttackGoal<>(this, 1.0D, 20, 15.0F) {
            @Override
            public boolean canUse() {
                return super.canUse() && isHolding(Items.BOW);
            }
        });

        // 3. MELEE ATTACK
        // Only works if NOT holding a bow
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2, false) {
            @Override
            public boolean canUse() {
                return super.canUse() && !isHolding(Items.BOW);
            }
        });

        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

        // --- TARGETING ---
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this).setAlertOthers());

        // Guards & Adventurers -> Hunt Monsters, Bandits & Undead
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Monster.class, true) {
            @Override
            public boolean canUse() {
                return super.canUse() && (getJob() == JobType.GUARD || getJob() == JobType.ADVENTURER);
            }
        });

        // Guards & Adventurers -> Attack Bandits specifically
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, RaceEntity.class, true) {
            @Override
            public boolean canUse() {
                return super.canUse() && (getJob() == JobType.GUARD || getJob() == JobType.ADVENTURER)
                        && ((RaceEntity)target).getJob() == JobType.BANDIT;
            }
        });

        // Bandits -> Hunt Players, Villagers, and Non-Bandits
        if (getJob() == JobType.BANDIT) {
            this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
            this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, AbstractVillager.class, false));
            this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, RaceEntity.class, true) {
                @Override
                public boolean canUse() {
                    return super.canUse() && ((RaceEntity)this.target).getJob() != JobType.BANDIT;
                }
            });
        }
    }

    // --- Ranged Combat Logic ---
    @Override
    public void performRangedAttack(LivingEntity target, float distanceFactor) {
        ItemStack itemstack = this.getItemInHand(ProjectileUtil.getWeaponHoldingHand(this, item -> item instanceof ProjectileWeaponItem));
        ItemStack ammo = this.getProjectile(itemstack);

        AbstractArrow arrow = ProjectileUtil.getMobArrow(this, ammo, distanceFactor, itemstack);

        if (this.getMainHandItem().getItem() instanceof ProjectileWeaponItem) {
            arrow = ProjectileUtil.getMobArrow(this, new ItemStack(Items.ARROW), distanceFactor, this.getMainHandItem());
        }

        double d0 = target.getX() - this.getX();
        double d1 = target.getY(0.3333333333333333D) - arrow.getY();
        double d2 = target.getZ() - this.getZ();
        double d3 = Math.sqrt(d0 * d0 + d2 * d2);

        arrow.shoot(d0, d1 + d3 * 0.20000000298023224D, d2, 1.6F, (float)(14 - this.level().getDifficulty().getId() * 4));

        // NOTE: SoundEvents.SKELETON_SHOOT works as a SoundEvent in your build
        this.playSound(SoundEvents.SKELETON_SHOOT, 1.0F, 1.0F / (this.getRandom().nextFloat() * 0.4F + 0.8F));

        this.level().addFreshEntity(arrow);
    }

    // --- Main Tick: Handle Sheathing & Animation ---
    @Override
    public void tick() {
        super.tick();

        if (!this.level().isClientSide) {
            // 1. Update Aggressive State (Triggers Attack Animation)
            boolean isCombating = this.getTarget() != null && this.getTarget().isAlive();
            this.setAggressive(isCombating);

            // 2. Weapon Sheathing Logic
            updateWeaponSheathing(isCombating);
        }

        // Particle Effects for Traits
        if (this.level().isClientSide && this.tickCount % 20 == 0) {
            String traitStr = this.entityData.get(DATA_TRAITS);
            if (traitStr.contains("CURSED")) this.level().addParticle(ParticleTypes.SMOKE, getX(), getY() + 2, getZ(), 0, 0, 0);
            if (traitStr.contains("BLESSED")) this.level().addParticle(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 2, getZ(), 0, 0, 0);
        }
    }

    private void updateWeaponSheathing(boolean isCombating) {
        ItemStack mainHand = this.getItemBySlot(EquipmentSlot.MAINHAND);

        // CASE A: Entering Combat (Unsheathe)
        if (isCombating) {
            // If hand is empty but we have a weapon stored, pull it out
            if (mainHand.isEmpty() && !this.storedWeapon.isEmpty()) {
                this.setItemSlot(EquipmentSlot.MAINHAND, this.storedWeapon.copy());
                this.storedWeapon = ItemStack.EMPTY;

                // FIXED LINE: Added .value() because ARMOR_EQUIP_IRON is a Holder in your build
                this.playSound(SoundEvents.ARMOR_EQUIP_IRON.value(), 1.0f, 1.0f);
            }
        }
        // CASE B: Leaving Combat (Sheathe)
        else {
            // If hand has weapon and we have room, hide it
            if (!mainHand.isEmpty() && this.storedWeapon.isEmpty()) {
                this.storedWeapon = mainHand.copy();
                this.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            }
        }
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason, @Nullable SpawnGroupData spawnData) {
        RandomSource r = this.getRandom();

        // 1. Race Selection
        String registryName = this.getType().getDescriptionId();
        boolean found = false;
        for (RaceType type : RaceType.values()) {
            if (registryName.toLowerCase().contains(type.getSerializedName())) {
                setRace(type);
                found = true;
                break;
            }
        }
        if (!found) setRace(RaceType.values()[r.nextInt(RaceType.values().length)]);

        // 2. Job Selection
        float jobRoll = r.nextFloat();
        if (jobRoll < 0.10) setJob(JobType.ADVENTURER);
        else if (jobRoll < 0.25) setJob(JobType.BANDIT);
        else setJob(JobType.values()[r.nextInt(JobType.values().length)]);

        setSkinId(r.nextInt(Config.SKINS_PER_RACE.get()) + 1);

        // 3. Stats & Traits
        this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(getRaceType().getMaxHealth());
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(getRaceType().getSpeed());
        this.setHealth(this.getMaxHealth());

        generateTraits(r);
        generateName();

        // 4. Equip Items (Including Bows)
        equipJobItems(r);

        return super.finalizeSpawn(level, difficulty, reason, spawnData);
    }

    private void generateTraits(RandomSource r) {
        int traitCount = r.nextInt(3) + 1;
        List<Trait> pickedTraits = new ArrayList<>();
        Trait[] allTraits = Trait.values();
        for (int i = 0; i < traitCount; i++) {
            Trait t = allTraits[r.nextInt(allTraits.length)];
            if (!pickedTraits.contains(t)) {
                pickedTraits.add(t);
                t.apply(this);
            }
        }
        this.entityData.set(DATA_TRAITS, pickedTraits.stream().map(Enum::name).collect(Collectors.joining(",")));
    }

    private void equipJobItems(RandomSource r) {
        // Chance for Bow (30% for Guard/Bandit/Adventurer)
        boolean useBow = r.nextFloat() < 0.30;

        if (getJob() == JobType.GUARD) {
            if (useBow) this.storedWeapon = new ItemStack(Items.BOW);
            else this.storedWeapon = new ItemStack(Items.IRON_SWORD);

            this.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
            this.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.IRON_CHESTPLATE));
            this.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.IRON_LEGGINGS));
            this.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.IRON_BOOTS));
        }
        else if (getJob() == JobType.BANDIT) {
            if (useBow) this.storedWeapon = new ItemStack(Items.BOW);
            else this.storedWeapon = new ItemStack(Items.IRON_AXE);

            this.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.LEATHER_HELMET));
            this.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.LEATHER_CHESTPLATE));
        }
        else if (getJob() == JobType.ADVENTURER) {
            if (useBow) this.storedWeapon = new ItemStack(Items.BOW);
            else this.storedWeapon = new ItemStack(Items.DIAMOND_SWORD);

            this.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.CHAINMAIL_HELMET));
            this.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.IRON_CHESTPLATE));
        }
        else if (getJob() == JobType.CIVILIAN || getJob() == JobType.TRADER) {
            if (r.nextFloat() < 0.5) {
                this.storedWeapon = new ItemStack(Items.WOODEN_SWORD);
            }
        }

        // Ensure weapon is hidden on spawn (It will be pulled out if they spawn in danger)
        this.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
    }

    private void generateName() {
        List<? extends String> fNames = Config.FIRST_NAMES.get();
        List<? extends String> lNames = Config.LAST_NAMES.get();
        List<? extends String> titles = Config.TITLES.get();
        RandomSource r = this.getRandom();
        if (fNames.isEmpty() || lNames.isEmpty()) return;

        String fullName = fNames.get(r.nextInt(fNames.size())) + " " + lNames.get(r.nextInt(lNames.size()));
        String traitStr = this.entityData.get(DATA_TRAITS);

        if (getJob() == JobType.BANDIT) fullName += " the Bandit";
        else {
            if (traitStr.contains("SWORD_MASTER")) fullName += " the Blade";
            else if (traitStr.contains("GIANT")) fullName += " the Giant";
            else if (r.nextFloat() < 0.3 && !titles.isEmpty()) fullName += " " + titles.get(r.nextInt(titles.size()));
        }

        this.setCustomName(Component.literal(fullName));
        this.setCustomNameVisible(true);
    }

    // Aggro/Help Logic
    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean wasHurt = super.hurt(source, amount);
        if (wasHurt && source.getEntity() instanceof LivingEntity attacker) {
            if ((getHealth() / getMaxHealth()) > 0.30f) this.setTarget(attacker);
            alertAllies(attacker);
        }
        return wasHurt;
    }

    private void alertAllies(LivingEntity attacker) {
        if (this.level().isClientSide) return;
        AABB searchBox = this.getBoundingBox().inflate(20.0);
        List<RaceEntity> allies = this.level().getEntitiesOfClass(RaceEntity.class, searchBox);
        for (RaceEntity ally : allies) {
            boolean sameFaction = false;
            if (this.getJob() == JobType.BANDIT && ally.getJob() == JobType.BANDIT) sameFaction = true;
            boolean thisIsCivil = this.getJob() != JobType.BANDIT;
            boolean allyIsProtector = (ally.getJob() == JobType.GUARD || ally.getJob() == JobType.ADVENTURER);
            if (thisIsCivil && allyIsProtector) sameFaction = true;

            if (sameFaction && ally != this && ally.isAlive()) {
                ally.setTarget(attacker);
            }
        }
    }

    // NBT Saving
    public void setRace(RaceType race) { this.entityData.set(DATA_RACE, race.getSerializedName()); }
    public RaceType getRaceType() { return RaceType.valueOf(this.entityData.get(DATA_RACE).toUpperCase()); }
    public void setJob(JobType job) { this.entityData.set(DATA_JOB, job.name()); }
    public JobType getJob() { return JobType.valueOf(this.entityData.get(DATA_JOB)); }
    public void setSkinId(int id) { this.entityData.set(DATA_SKIN_ID, id); }
    public int getSkinId() { return this.entityData.get(DATA_SKIN_ID); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("Race", this.entityData.get(DATA_RACE));
        tag.putString("Job", this.entityData.get(DATA_JOB));
        tag.putInt("SkinID", this.entityData.get(DATA_SKIN_ID));
        tag.putString("Traits", this.entityData.get(DATA_TRAITS));
        if (!this.storedWeapon.isEmpty()) tag.put("StoredWeapon", this.storedWeapon.save(this.registryAccess()));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if(tag.contains("Race")) this.entityData.set(DATA_RACE, tag.getString("Race"));
        if(tag.contains("Job")) this.entityData.set(DATA_JOB, tag.getString("Job"));
        if(tag.contains("SkinID")) this.entityData.set(DATA_SKIN_ID, tag.getInt("SkinID"));
        if(tag.contains("Traits")) this.entityData.set(DATA_TRAITS, tag.getString("Traits"));
        if(tag.contains("StoredWeapon")) this.storedWeapon = ItemStack.parse(this.registryAccess(), tag.getCompound("StoredWeapon")).orElse(ItemStack.EMPTY);
    }
}