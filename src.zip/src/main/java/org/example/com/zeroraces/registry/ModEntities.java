package org.example.com.zeroraces.registry;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.example.com.zeroraces.ZeroRaces;
import org.example.com.zeroraces.entity.RaceEntity;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ZeroRaces.MODID);

    // Helper method to create entities easily
    private static RegistryObject<EntityType<RaceEntity>> registerRace(String name, float width, float height) {
        return ENTITIES.register(name, () -> EntityType.Builder.of(RaceEntity::new, MobCategory.CREATURE)
                .sized(width, height)
                .build(name));
    }

    // Register all your races here
    public static final RegistryObject<EntityType<RaceEntity>> HUMAN = registerRace("human", 0.6f, 1.8f);
    public static final RegistryObject<EntityType<RaceEntity>> ELF = registerRace("elf", 0.6f, 1.8f);
    public static final RegistryObject<EntityType<RaceEntity>> DWARF = registerRace("dwarf", 0.7f, 1.5f);
    public static final RegistryObject<EntityType<RaceEntity>> KOBOLD = registerRace("kobold", 0.5f, 1.2f);
    public static final RegistryObject<EntityType<RaceEntity>> DRAGONKIN = registerRace("dragonkin", 0.7f, 2.0f);
    public static final RegistryObject<EntityType<RaceEntity>> BEASTFOLK = registerRace("beastfolk", 0.6f, 1.8f);
    public static final RegistryObject<EntityType<RaceEntity>> DEMON = registerRace("demon", 0.7f, 2.1f);

    public static void register(IEventBus eventBus) {
        ENTITIES.register(eventBus);
    }
}