package org.example.com.zeroraces.entity;

import net.minecraft.util.StringRepresentable;

public enum RaceType implements StringRepresentable {
    HUMAN("human", 20.0, 0.23),
    ELF("elf", 18.0, 0.26),
    DWARF("dwarf", 24.0, 0.20),
    KOBOLD("kobold", 14.0, 0.28),
    DRAGONKIN("dragonkin", 30.0, 0.22),
    BEASTFOLK("beastfolk", 22.0, 0.25),
    DEMON("demon", 40.0, 0.24); // <--- NEW RACE: High Health;

    private final String name;
    private final double maxHealth;
    private final double speed;

    RaceType(String name, double maxHealth, double speed) {
        this.name = name;
        this.maxHealth = maxHealth;
        this.speed = speed;
    }

    public double getMaxHealth() { return maxHealth; }
    public double getSpeed() { return speed; }

    @Override
    public String getSerializedName() { return this.name; }
}