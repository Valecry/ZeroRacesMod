package org.example.com.zeroraces.entity;

public enum JobType {
    CIVILIAN,
    TRADER,
    GUARD,
    ADVENTURER,
    BANDIT
}