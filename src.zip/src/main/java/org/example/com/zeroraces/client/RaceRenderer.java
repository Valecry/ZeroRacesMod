package org.example.com.zeroraces.client;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import org.example.com.zeroraces.ZeroRaces;
import org.example.com.zeroraces.entity.RaceEntity;

public class RaceRenderer extends HumanoidMobRenderer<RaceEntity, PlayerModel<RaceEntity>> {

    public RaceRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false), 0.5f);

        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
                context.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(RaceEntity entity) {
        String race = entity.getRaceType().getSerializedName();
        int id = entity.getSkinId();
        return ResourceLocation.fromNamespaceAndPath(ZeroRaces.MODID,
                "textures/entity/" + race + "/" + race + "_" + id + ".png");
    }

    @Override
    protected void scale(RaceEntity entity, com.mojang.blaze3d.vertex.PoseStack poseStack, float partialTickTime) {
        // This makes sure the entity size attribute (Giant/Tiny traits) actually visually scales the model
        // Minecraft 1.21 usually handles this automatically via the attribute, but explicit scale confirms it.
        float scale = (float) entity.getScale();
        poseStack.scale(scale, scale, scale);
    }

    // This helps set the correct arm pose (Bow holding vs Sword)
    @Override
    protected void setupRotations(RaceEntity entity, com.mojang.blaze3d.vertex.PoseStack poseStack, float bob, float yBodyRot, float partialTick, float scale) {
        super.setupRotations(entity, poseStack, bob, yBodyRot, partialTick, scale);

        ItemStack mainHand = entity.getItemInHand(InteractionHand.MAIN_HAND);

        if (entity.isAggressive()) {
            if (mainHand.is(Items.BOW)) {
                this.model.rightArmPose = HumanoidModel.ArmPose.BOW_AND_ARROW;
            } else if (!mainHand.isEmpty()) {
                this.model.rightArmPose = HumanoidModel.ArmPose.ITEM;
            }
        } else {
            this.model.rightArmPose = HumanoidModel.ArmPose.EMPTY;
        }
    }
}