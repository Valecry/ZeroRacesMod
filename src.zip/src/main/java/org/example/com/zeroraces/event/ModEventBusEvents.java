package org.example.com.zeroraces.event;

import org.example.com.zeroraces.ZeroRaces;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.StructureTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid = "zeroraces", bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEventBusEvents {

    @SubscribeEvent
    public static void registerSpawnPlacements(SpawnPlacementRegisterEvent event) {
        // Register your races using their ID strings
        registerVillageBiasSpawn(event, "human");
        registerVillageBiasSpawn(event, "elf");
        registerVillageBiasSpawn(event, "dwarf");
        registerVillageBiasSpawn(event, "dragonkin");
        registerVillageBiasSpawn(event, "beastfolk");
        registerVillageBiasSpawn(event, "kobold");
    }

    private static void registerVillageBiasSpawn(SpawnPlacementRegisterEvent event, String entityName) {
        // Find the entity by ID (Fixes the RaceType error)
        ResourceLocation location = ResourceLocation.fromNamespaceAndPath("zeroraces", entityName);
        EntityType<?> entityType = ForgeRegistries.ENTITY_TYPES.getValue(location);

        if (entityType == null) {
            System.out.println("ZeroRaces ERROR: Could not find entity " + entityName);
            return;
        }

        try {
            // Assuming your entities extend Animal. If they are Monsters, change Animal to Monster.
            @SuppressWarnings("unchecked")
            EntityType<Animal> castedEntity = (EntityType<Animal>) entityType;

            event.register(
                    castedEntity,
                    SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    ModEventBusEvents::checkZeroRaceSpawnRules,
                    SpawnPlacementRegisterEvent.Operation.REPLACE
            );
        } catch (ClassCastException e) {
            System.out.println("ZeroRaces ERROR: " + entityName + " is not an Animal!");
        }
    }

    // THE SMART LOGIC
    public static boolean checkZeroRaceSpawnRules(EntityType<? extends Animal> entityType, LevelAccessor level, MobSpawnType spawnType, BlockPos pos, RandomSource random) {
        // 1. Ground Check: Must be on a solid block (not air/water)
        if (level.getBlockState(pos.below()).isAir()) return false;

        // 2. Village vs Wild Logic
        if (level instanceof ServerLevel serverLevel) {
            // Check if we are inside a Village
            boolean isVillage = serverLevel.structureManager().getStructureWithPieceAt(pos, StructureTags.VILLAGE).isValid();

            if (isVillage) {
                return true; // 100% chance to spawn if in a Village
            } else {
                // In the Wild, we cancel 95% of spawns.
                // This makes them RARE in the wild, even if the spawn weight is high.
                return random.nextFloat() < 0.05f;
            }
        }
        return true;
    }
}