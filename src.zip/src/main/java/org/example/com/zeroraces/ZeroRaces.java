package org.example.com.zeroraces;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import org.example.com.zeroraces.client.RaceRenderer;
import org.example.com.zeroraces.entity.RaceEntity;
import org.example.com.zeroraces.registry.ModEntities;
import org.example.com.zeroraces.registry.ModItems;

@Mod(ZeroRaces.MODID)
public class ZeroRaces {
    public static final String MODID = "zeroraces";

    public ZeroRaces() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        ModEntities.register(modEventBus);
        ModItems.register(modEventBus);

        modEventBus.addListener(this::addEntityAttributes);
        modEventBus.addListener(this::registerSpawnPlacements);

        // Register the Event Bus to handle player joins
        MinecraftForge.EVENT_BUS.register(this);
    }

    // --- EARLY ACCESS WARNING MESSAGE ---
    @SubscribeEvent
    public void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
        if (Config.ENABLE_EARLY_ACCESS_WARNING.get()) {
            event.getEntity().sendSystemMessage(Component.literal("")
                    .append(Component.literal("[ZeroRaces] ").withStyle(ChatFormatting.RED, ChatFormatting.BOLD))
                    .append(Component.literal("This mod is in ").withStyle(ChatFormatting.GOLD))
                    .append(Component.literal("EARLY ACCESS").withStyle(ChatFormatting.RED, ChatFormatting.UNDERLINE))
                    .append(Component.literal(". Expect bugs!").withStyle(ChatFormatting.GOLD)));

            event.getEntity().sendSystemMessage(Component.literal("(Disable this in config)")
                    .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
        }
    }

    private void addEntityAttributes(EntityAttributeCreationEvent event) {
        ModEntities.ENTITIES.getEntries().forEach(entry -> {
            EntityType<? extends LivingEntity> type = (EntityType<? extends LivingEntity>) entry.get();
            event.put(type, RaceEntity.createAttributes().build());
        });
    }

    private void registerSpawnPlacements(SpawnPlacementRegisterEvent event) {
        ModEntities.ENTITIES.getEntries().forEach(entry -> {
            event.register(
                    (EntityType<RaceEntity>) entry.get(),
                    SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    RaceEntity::checkRaceSpawnRules,
                    SpawnPlacementRegisterEvent.Operation.REPLACE
            );
        });
    }

    @Mod.EventBusSubscriber(modid = MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientModEvents {
        @SubscribeEvent
        public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
            ModEntities.ENTITIES.getEntries().forEach(entry -> {
                event.registerEntityRenderer((EntityType<RaceEntity>) entry.get(), RaceRenderer::new);
            });
        }
    }
}