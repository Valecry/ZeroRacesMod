package org.example.com.zeroraces.config;

import net.minecraftforge.common.ForgeConfigSpec;
import java.util.Arrays;
import java.util.List;

public class RaceConfig {
    public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> FIRST_NAMES;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> LAST_NAMES;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> TITLES;
    public static final ForgeConfigSpec.IntValue SKINS_PER_RACE;

    static {
        BUILDER.push("General Settings");

        SKINS_PER_RACE = BUILDER.comment("How many skin variants exist per race folder?")
                .defineInRange("skinsPerRace", 12, 1, 100);

        BUILDER.push("Name Generation");

        FIRST_NAMES = BUILDER.comment("List of 150 first names used for random generation")
                .defineList("firstNames", Arrays.asList(
                        "Aaelin", "Adran", "Aelar", "Aeris", "Aethel", "Alaric", "Alden", "Alina", "Altair", "Amara",
                        "Andor", "Aranis", "Aric", "Arin", "Arlen", "Astrid", "Aveline", "Azura", "Bael", "Balthazar",
                        "Barin", "Beorn", "Berin", "Bram", "Bryn", "Caelum", "Caius", "Calen", "Cassian", "Cedric",
                        "Caelan", "Corwin", "Cyril", "Daalis", "Dain", "Darian", "Darius", "Davina", "Dorn", "Drog",
                        "Drustan", "Eamon", "Edric", "Eira", "Elara", "Elian", "Elric", "Elysia", "Emrys", "Eoran",
                        "Eovan", "Erwann", "Esmeray", "Evander", "Faela", "Faelar", "Fenris", "Fintan", "Fiora", "Florian",
                        "Gael", "Galen", "Garret", "Garrick", "Gavriel", "Gideon", "Grom", "Gwen", "Hadrian", "Haldor",
                        "Halia", "Hera", "Hesper", "Idril", "Ignis", "Ilias", "Imryll", "Ion", "Isolde", "Ivar",
                        "Jareth", "Jorun", "Kael", "Kaida", "Kaelen", "Kainan", "Karas", "Kasin", "Kea", "Kian",
                        "Kylian", "Kyra", "Leif", "Lian", "Lorcan", "Lucan", "Lyra", "Lysander", "Magnus", "Maelor",
                        "Malakai", "Marek", "Marius", "Miro", "Morrigan", "Nael", "Nareen", "Nevan", "Nia", "Nyx",
                        "Oberon", "Oisin", "Orion", "Orla", "Osric", "Pael", "Perrin", "Phineas", "Quinlan", "Rael",
                        "Ragnor", "Raven", "Reinhart", "Ren", "Rhiannon", "Rian", "Roan", "Ronan", "Rowan", "Rurik",
                        "Sariel", "Seren", "Silas", "Soren", "Stellan", "Taelon", "Talon", "Thalas", "Thane", "Thea",
                        "Theron", "Thorin", "Tian", "Torian", "Tristan", "Tybalt", "Ulric", "Valen", "Vane", "Varis",
                        "Vera", "Vesper", "Vorin", "Xander", "Xylia", "Yara", "Yorick", "Zael", "Zane", "Zephyr"
                ), o -> o instanceof String);

        LAST_NAMES = BUILDER.comment("List of 150 last names used for random generation")
                .defineList("lastNames", Arrays.asList(
                        "Ashdown", "Ashwalker", "Amberhill", "Argent", "Arroway", "Arkwright", "Battleborn", "Bearclaw", "Beastwalker", "Blackwood",
                        "Blackthorn", "Bloodraven", "Bonebreaker", "Brightflame", "Brimstone", "Broadleaf", "Bronzebeard", "Cairn", "Coldwater", "Copperpot",
                        "Crownguard", "Darkmore", "Darkwater", "Dawnbringer", "Dawnstrider", "Deepdelver", "Dragonbane", "Drakewing", "Duskrunner", "Duskwalker",
                        "Eagleeye", "Earthshaker", "Emberfall", "Emberforge", "Evergreen", "Fairwind", "Falconflight", "Farwalker", "Featherfoot", "Fireforge",
                        "Fireheart", "Fleetfoot", "Frostbeard", "Frostfall", "Frostweaver", "Gloomstalker", "Goldenshield", "Goldleaf", "Grandhammer", "Graycloud",
                        "Graylock", "Greenleaf", "Grimward", "Hammerfall", "Hartwood", "Hawksight", "Hazelhollow", "Highwind", "Holloway", "Ice-Eye",
                        "Ironbark", "Ironfist", "Ironfoot", "Ironheart", "Ironroot", "Kingslayer", "Lightbringer", "Lionheart", "Longstrider", "Lorekeeper",
                        "Marblefist", "Mistwalker", "Moonblade", "Moonsong", "Moonwhisper", "Morningstar", "Mossheart", "Nightbane", "Nightshade", "Northwind",
                        "Oakenshield", "Oakenstaff", "Oakheart", "Onyxblood", "Paleleaf", "Quickstrike", "Raindancer", "Ravenwood", "Redmain", "Rivergleam",
                        "Riverrun", "Rockfist", "Rootwalker", "Rosewood", "Runebreaker", "Runecarver", "Sageleaf", "Scalebound", "Seastrider", "Shadowcloak",
                        "Shadowend", "Shadowstep", "Shadowwalker", "Shieldbreaker", "Silverbow", "Silverleaf", "Silvermoon", "Silvershield", "Skybreaker", "Skywatcher",
                        "Slatefist", "Smith", "Snowmane", "Spellweaver", "Springsong", "Staghart", "Starfall", "Stargazer", "Steelbreaker", "Steelwind",
                        "Stonebridge", "Stonecleaver", "Stonehand", "Stormborn", "Stormbreaker", "Stormcaller", "Stormcrow", "Stormrider", "Strongbow", "Summerisle",
                        "Sunforged", "Sunstrider", "Swiftblade", "Swiftfoot", "Swiftwind", "Thornheart", "Thunderfist", "Thunderhoof", "Tidecaller", "Trueshot",
                        "Underhill", "Valestream", "Voidwalker", "Warforge", "Whitewater", "Wildblood", "Wildheart", "Windrider", "Windrunner", "Windwhisper",
                        "Winterborn", "Wintermoon", "Wolfsbane", "Wolfwalker", "Woodwalker", "Wyrmslayer", "Yewdale", "Zephyrwing", "Ironvein", "Deeprock"
                ), o -> o instanceof String);

        TITLES = BUILDER.comment("List of 150 titles (30% chance to appear)")
                .defineList("titles", Arrays.asList(
                        "the Brave", "the Bold", "the Swift", "the Strong", "the Wise", "the Just", "the Cruel", "the Kind", "the Fair", "the Dark",
                        "the Light", "the Grey", "the White", "the Black", "the Red", "the Blue", "the Green", "the Golden", "the Silver", "the Iron",
                        "the Steel", "the Stone", "the Wooden", "the Ancient", "the Young", "the Old", "the Elder", "the Younger", "the Great", "the Small",
                        "the Tall", "the Short", "the Giant", "the Tiny", "the Mad", "the Sane", "the Wild", "the Tame", "the Fierce", "the Gentle",
                        "the Silent", "the Loud", "the Quiet", "the Noisy", "the Quick", "the Slow", "the Fast", "the Heavy", "the Light-Footed", "the Heavy-Handed",
                        "the Sharp", "the Dull", "the Bright", "the Dim", "the Shadow", "the Ghost", "the Spirit", "the Soul", "the Heart", "the Mind",
                        "the Eye", "the Ear", "the Hand", "the Foot", "the Arm", "the Leg", "the Head", "the Body", "the Blood", "the Bone",
                        "the Flesh", "the Skin", "the Scale", "the Fur", "the Feather", "the Claw", "the Tooth", "the Nail", "the Horn", "the Tail",
                        "the Wing", "the Fin", "the Beak", "the Snout", "the Maw", "the Tongue", "the Throat", "the Neck", "the Shoulder", "the Chest",
                        "the Back", "the Spine", "the Rib", "the Hip", "the Thigh", "the Knee", "the Shin", "the Ankle", "the Heel", "the Toe",
                        "Dragon-Slayer", "Giant-Killer", "Orc-Bane", "Elf-Friend", "Dwarf-Lord", "King-Maker", "Queen-Slayer", "Prince-Regent", "Princess-Royal", "Duke-Consort",
                        "Baron-Knight", "Count-Paladin", "Marquis-General", "Earl-Marshal", "Viscount-Admiral", "Lord-Commander", "Lady-Captain", "Sir-Knight", "Dame-Warrior", "Master-Mage",
                        "Mistress-Witch", "Sorcerer-Supreme", "Wizard-King", "Warlock-Lord", "Cleric-Priest", "Druid-Elder", "Ranger-Scout", "Rogue-Thief", "Bard-Singer", "Monk-Master",
                        "Paladin-Champion", "Barbarian-Chief", "Fighter-Veteran", "Warrior-Hero", "Guardian of the Valley", "Protector of the Realm", "Keeper of the Flame", "Watcher of the Woods", "Sentinel of the North", "Warden of the South"
                ), o -> o instanceof String);

        BUILDER.pop();
        BUILDER.pop();
        SPEC = BUILDER.build();
    }
}