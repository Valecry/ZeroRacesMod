package org.example.com.zeroraces;

import net.minecraftforge.common.ForgeConfigSpec;
import java.util.Arrays;
import java.util.List;

public class Config {
    public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec SPEC;

    // --- General Settings ---
    public static final ForgeConfigSpec.BooleanValue ENABLE_EARLY_ACCESS_WARNING;
    public static final ForgeConfigSpec.IntValue SKINS_PER_RACE;

    // --- Name Generation ---
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> FIRST_NAMES;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> LAST_NAMES;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> TITLES;

    static {
        // 1. General Settings Category
        BUILDER.push("General Settings");

        ENABLE_EARLY_ACCESS_WARNING = BUILDER.comment("Show a warning message about Early Access when a player joins the world.")
                .define("enableEarlyAccessWarning", true);

        SKINS_PER_RACE = BUILDER.comment("How many skin variants exist per race folder?")
                .defineInRange("skinsPerRace", 12, 1, 100);

        BUILDER.pop(); // Exit "General Settings"

        // 2. Name Generation Category
        BUILDER.push("Name Generation");

        FIRST_NAMES = BUILDER.comment("List of first names used for random generation")
                .defineList("firstNames", Arrays.asList(
                        "Aaelin", "Adran", "Aelar", "Aeris", "Alaric", "Alden", "Alina", "Altair", "Amara",
                        "Andor", "Aranis", "Aric", "Arin", "Arlen", "Astrid", "Aveline", "Azura", "Bael",
                        "Balthazar", "Barin", "Beorn", "Berin", "Bram", "Bryn", "Caelum", "Caius", "Calen",
                        "Cassian", "Cedric", "Corwin", "Cyril", "Dain", "Darian", "Darius", "Davina", "Dorn",
                        "Drog", "Eamon", "Edric", "Eira", "Elara", "Elric", "Emrys", "Faela", "Fenris",
                        "Gael", "Galen", "Garret", "Gideon", "Grom", "Gwen", "Hadrian", "Haldor", "Ignis",
                        "Isolde", "Ivar", "Jareth", "Kael", "Kaida", "Kian", "Kyra", "Leif", "Lyra", "Lysander",
                        "Magnus", "Malakai", "Marek", "Marius", "Morrigan", "Nyx", "Oberon", "Orion", "Osric",
                        "Raven", "Ren", "Rhiannon", "Ronan", "Rowan", "Rurik", "Sariel", "Seren", "Silas",
                        "Soren", "Stellan", "Talon", "Thane", "Thea", "Thorin", "Torian", "Tristan", "Tybalt",
                        "Ulric", "Valen", "Vane", "Varis", "Vera", "Vesper", "Vorin", "Xander", "Zael", "Zane", "Zephyr"
                ), o -> o instanceof String);

        LAST_NAMES = BUILDER.comment("List of last names used for random generation")
                .defineList("lastNames", Arrays.asList(
                        "Ashdown", "Ashwalker", "Argent", "Battleborn", "Bearclaw", "Blackwood", "Blackthorn",
                        "Bloodraven", "Bonebreaker", "Brightflame", "Brimstone", "Bronzebeard", "Coldwater",
                        "Crownguard", "Darkmore", "Dawnstrider", "Deepdelver", "Dragonbane", "Duskrunner",
                        "Earthshaker", "Emberfall", "Evergreen", "Fairwind", "Fireheart", "Fleetfoot",
                        "Frostbeard", "Goldenshield", "Grimward", "Hammerfall", "Hawksight", "Highwind",
                        "Ironbark", "Ironfist", "Ironfoot", "Ironheart", "Kingslayer", "Lightbringer",
                        "Lionheart", "Longstrider", "Moonblade", "Moonsong", "Morningstar", "Nightbane",
                        "Nightshade", "Oakenshield", "Oakenstaff", "Quickstrike", "Raindancer", "Ravenwood",
                        "Redmain", "Riverrun", "Rockfist", "Runebreaker", "Shadowcloak", "Shadowstep",
                        "Shieldbreaker", "Silverbow", "Silverleaf", "Skybreaker", "Slatefist", "Smith",
                        "Spellweaver", "Starfall", "Steelbreaker", "Stonehand", "Stormborn", "Stormbreaker",
                        "Stormcrow", "Strongbow", "Sunstrider", "Swiftblade", "Thunderfist", "Voidwalker",
                        "Warforge", "Whitewater", "Wildblood", "Windrunner", "Winterborn", "Wolfsbane", "Wyrmslayer"
                ), o -> o instanceof String);

        TITLES = BUILDER.comment("List of titles (30% chance to appear)")
                .defineList("titles", Arrays.asList(
                        "the Brave", "the Bold", "the Swift", "the Strong", "the Wise", "the Just", "the Cruel",
                        "the Kind", "the Dark", "the Light", "the Grey", "the White", "the Black", "the Red",
                        "the Ancient", "the Young", "the Old", "the Great", "the Giant", "the Tiny", "the Mad",
                        "the Wild", "the Fierce", "the Silent", "the Quick", "Dragon-Slayer", "Giant-Killer",
                        "Orc-Bane", "Elf-Friend", "Dwarf-Lord", "King-Maker", "Lord-Commander", "Lady-Captain",
                        "Master-Mage", "Paladin-Champion", "Barbarian-Chief", "Guardian of the Valley"
                ), o -> o instanceof String);

        BUILDER.pop(); // Exit "Name Generation"

        // FIXED: Removed the extra BUILDER.pop() that was causing the crash here.

        SPEC = BUILDER.build();
    }
}