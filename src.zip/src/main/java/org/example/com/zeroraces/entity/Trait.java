package org.example.com.zeroraces.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;
import org.example.com.zeroraces.ZeroRaces;

import java.util.List;

public enum Trait {
    // ==================================================================================
    // === ORIGINAL TRAITS (Passive) ====================================================
    // ==================================================================================
    GIANT("Giant", 0.5, 10.0, -0.05, 2.0, 0.0, 0.2, null),
    COLOSSAL("Colossal", 1.0, 30.0, -0.15, 6.0, 2.0, 0.5, null),
    TINY("Tiny", -0.4, -6.0, 0.1, -1.0, 0.0, -0.2, null),
    MICROSCOPIC("Microscopic", -0.6, -10.0, 0.2, -2.0, 0.0, -0.5, null),
    TOWERING("Towering", 0.3, 5.0, 0.0, 1.0, 0.0, 0.1, null),
    STUNTED("Stunted", -0.2, -2.0, -0.05, 0.0, 0.0, 0.0, null),
    LANKY("Lanky", 0.15, -2.0, 0.05, 0.0, 0.0, -0.1, null),
    STOUT("Stout", -0.15, 4.0, -0.05, 0.0, 1.0, 0.2, null),
    OBESE("Obese", 0.1, 8.0, -0.2, 1.0, 0.0, 0.4, null),
    ATHLETIC("Athletic", 0.0, 4.0, 0.15, 1.0, 0.0, 0.0, null),
    MUSCULAR("Muscular", 0.05, 5.0, 0.0, 3.0, 0.0, 0.1, null),
    FRAIL("Frail", 0.0, -8.0, -0.1, -1.0, 0.0, -0.3, null),
    SICKLY("Sickly", 0.0, -10.0, -0.15, -2.0, 0.0, 0.0, null),
    STRONG("Strong", 0.0, 0.0, 0.0, 3.0, 0.0, 0.0, null),
    HERCULEAN("Herculean", 0.1, 10.0, 0.0, 8.0, 0.0, 0.2, null),
    WEAK("Weak", 0.0, 0.0, 0.0, -1.5, 0.0, -0.1, null),
    SWORD_MASTER("Sword Master", 0.0, 0.0, 0.1, 5.0, 0.0, 0.0, null),
    BRAWLER("Brawler", 0.0, 2.0, 0.0, 2.0, 0.0, 0.1, null),
    ASSASSIN("Assassin", 0.0, -4.0, 0.3, 6.0, 0.0, 0.0, null),
    TANK("Tank", 0.1, 20.0, -0.2, 0.0, 4.0, 0.6, null),
    GLASS_CANNON("Glass Cannon", 0.0, -10.0, 0.1, 10.0, 0.0, -0.2, null),
    SNIPER("Sniper", 0.0, 0.0, 0.0, 2.0, 0.0, 0.0, null),
    BERSERKER("Berserker", 0.0, 10.0, 0.15, 4.0, -2.0, 0.1, null),
    GUARDIAN("Guardian", 0.05, 10.0, -0.1, 0.0, 5.0, 0.3, null),
    IRON_SKIN("Iron Skin", 0.0, 0.0, -0.05, 0.0, 8.0, 0.1, null),
    THICK_SKULL("Thick Skull", 0.0, 5.0, 0.0, 0.0, 1.0, 0.2, null),
    AGILE("Agile", 0.0, 0.0, 0.2, 0.0, 0.0, 0.0, null),
    CLUMSY("Clumsy", 0.0, 0.0, -0.1, -1.0, 0.0, 0.0, null),
    SWIFT("Swift", 0.0, 0.0, 0.25, 0.0, 0.0, 0.0, null),
    SLUGGISH("Sluggish", 0.0, 0.0, -0.25, 0.0, 0.0, 0.0, null),
    LIGHT_FOOTED("Light-Footed", 0.0, 0.0, 0.1, 0.0, 0.0, -0.2, null),
    HEAVY_FOOTED("Heavy-Footed", 0.0, 0.0, -0.1, 0.0, 0.0, 0.4, null),
    GENIUS("Genius", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, null),
    LOW_IQ("Low IQ", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, null),
    INSANE("Insane", 0.0, 0.0, 0.2, 1.0, 0.0, 0.0, null),
    BRAVE("Brave", 0.0, 5.0, 0.0, 1.0, 0.0, 0.0, null),
    COWARDLY("Cowardly", 0.0, 0.0, 0.3, -2.0, 0.0, -0.5, null),
    CHARISMATIC("Charismatic", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, null),
    REPULSIVE("Repulsive", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, null),
    NOBLE("Noble", 0.0, 2.0, 0.0, 0.0, 2.0, 0.0, null),
    PEASANT("Peasant", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, null),
    ANCIENT("Ancient", 0.0, -5.0, -0.2, 5.0, 0.0, 0.0, null),
    YOUTHFUL("Youthful", -0.1, 5.0, 0.1, -1.0, 0.0, 0.0, null),
    BLESSED("Blessed", 0.0, 10.0, 0.1, 2.0, 2.0, 0.1, null),
    CURSED("Cursed", 0.0, -10.0, -0.1, -2.0, -2.0, -0.1, null),
    DEMIGOD("Demigod", 0.2, 50.0, 0.1, 10.0, 5.0, 0.5, null),
    UNDEAD("Undead", 0.0, 5.0, -0.1, 2.0, 0.0, 0.1, null),
    GHOSTLY("Ghostly", 0.0, -10.0, 0.2, 0.0, 0.0, 0.0, null),
    VAMPIRIC("Vampiric", 0.0, 5.0, 0.15, 3.0, 0.0, 0.0, null),
    DRAGON_BLOOD("Dragon-Blood", 0.1, 15.0, 0.0, 4.0, 4.0, 0.3, null),
    FEY_TOUCHED("Fey-Touched", -0.1, -2.0, 0.2, 1.0, 0.0, 0.0, null),
    VOID_TOUCHED("Void-Touched", 0.0, 10.0, 0.0, 5.0, 0.0, 0.0, null),
    ELEMENTAL("Elemental", 0.0, 5.0, 0.0, 2.0, 2.0, 0.0, null),
    PYROMANCER("Pyromancer", 0.0, 0.0, 0.0, 2.0, 0.0, 0.0, null),
    CRYOMANCER("Cryomancer", 0.0, 0.0, -0.1, 0.0, 2.0, 0.0, null),
    SCARRED("Scarred", 0.0, 2.0, 0.0, 0.0, 1.0, 0.0, null),
    ONE_EYED("One-Eyed", 0.0, 0.0, 0.0, -0.5, 0.0, 0.0, null),
    CRIPPLED("Crippled", 0.0, -5.0, -0.5, -2.0, 0.0, -0.5, null),
    BLIND("Blind", 0.0, 0.0, -0.3, -1.0, 0.0, 0.0, null),
    LUCKY("Lucky", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, null),
    UNLUCKY("Unlucky", 0.0, -2.0, 0.0, -1.0, 0.0, 0.0, null),
    RICH("Rich", 0.0, 0.0, 0.0, 0.0, 2.0, 0.0, null),
    POOR("Poor", 0.0, -2.0, 0.0, 0.0, 0.0, 0.0, null),
    GLUTTONOUS("Gluttonous", 0.1, 5.0, -0.1, 0.0, 0.0, 0.2, null),
    STARVING("Starving", -0.1, -5.0, -0.1, -2.0, 0.0, -0.1, null),

    // ==================================================================================
    // === NEW ADVANCED SWORD ARTS (Active) =============================================
    // ==================================================================================

    VOID_STEP("Void Step", 0.0, 0.0, 0.1, 2.0, 0.0, 0.0, new TraitAbility() {
        @Override
        public void onAttack(RaceEntity attacker, Entity target) {
            if (target instanceof LivingEntity && attacker.getRandom().nextFloat() < 0.3f) {
                Vec3 behind = target.position().add(target.getLookAngle().scale(-1.5));
                attacker.teleportTo(behind.x, target.getY(), behind.z);
                attacker.playSound(SoundEvents.ENDERMAN_TELEPORT, 1.0f, 1.0f);
            }
        }
    }),

    BLOOD_LETTER("Blood Letter", 0.0, -5.0, 0.0, 4.0, 0.0, 0.0, new TraitAbility() {
        @Override
        public void onAttack(RaceEntity attacker, Entity target) {
            attacker.heal(2.0f);
            spawnParticles(attacker, ParticleTypes.DAMAGE_INDICATOR, 5);
        }
    }),

    PARRY_MASTER("Parry Master", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, new TraitAbility() {
        @Override
        public void onHurt(RaceEntity victim, DamageSource source, float amount) {
            if (victim.getRandom().nextFloat() < 0.35f && source.getEntity() != null) {
                victim.playSound(SoundEvents.SHIELD_BLOCK, 1.0f, 1.0f);
                Entity attacker = source.getEntity();
                Vec3 vec = attacker.position().subtract(victim.position()).normalize().scale(1.2);
                attacker.push(vec.x, 0.4, vec.z);
            }
        }
    }),

    WHIRLWIND("Whirlwind", 0.0, 5.0, 0.0, 2.0, 2.0, 0.0, new TraitAbility() {
        @Override
        public void onAttack(RaceEntity attacker, Entity target) {
            if (attacker.tickCount % 20 == 0) {
                List<LivingEntity> nearby = attacker.level().getEntitiesOfClass(LivingEntity.class, attacker.getBoundingBox().inflate(3.0));
                for (LivingEntity e : nearby) {
                    if (e != attacker && e != target) {
                        e.hurt(attacker.damageSources().mobAttack(attacker), 4.0f);
                        e.push(0, 0.3, 0);
                    }
                }
                spawnParticles(attacker, ParticleTypes.SWEEP_ATTACK, 10);
                attacker.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 1.0f);
            }
        }
    }),

    PIERCER("Piercer", 0.0, 0.0, 0.0, 1.0, -2.0, 0.0, new TraitAbility() {
        @Override
        public void onAttack(RaceEntity attacker, Entity target) {
            if (target instanceof LivingEntity living) {
                living.hurt(attacker.damageSources().magic(), 4.0f);
            }
        }
    }),

    // ==================================================================================
    // === NEW SUPERNATURAL SKILLS (Active) =============================================
    // ==================================================================================

    PHANTOM("Phantom", 0.0, -10.0, 0.0, 0.0, 0.0, 0.0, new TraitAbility() {
        @Override
        public void onHurt(RaceEntity victim, DamageSource source, float amount) {
            spawnParticles(victim, ParticleTypes.POOF, 10);
            victim.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 60, 0));
            victim.teleportTo(victim.getX() + (Math.random()-0.5)*6, victim.getY(), victim.getZ() + (Math.random()-0.5)*6);
        }
    }),

    GRAVITY_WELL("Gravity Well", 0.0, 20.0, -0.2, 0.0, 5.0, 1.0, new TraitAbility() {
        @Override
        public void onTick(RaceEntity entity) {
            if (entity.tickCount % 80 == 0) {
                List<LivingEntity> nearby = entity.level().getEntitiesOfClass(LivingEntity.class, entity.getBoundingBox().inflate(12.0));
                for (LivingEntity e : nearby) {
                    if (e != entity) {
                        Vec3 pull = entity.position().subtract(e.position()).normalize().scale(0.8);
                        e.setDeltaMovement(e.getDeltaMovement().add(pull));
                    }
                }
                spawnParticles(entity, ParticleTypes.PORTAL, 30);
                entity.playSound(SoundEvents.BEACON_ACTIVATE, 2.0f, 0.5f);
            }
        }
    }),

    FROST_TOUCH("Frost Touch", 0.0, 0.0, -0.1, 0.0, 2.0, 0.0, new TraitAbility() {
        @Override
        public void onAttack(RaceEntity attacker, Entity target) {
            if (target instanceof LivingEntity living) {
                living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 4));
                living.setTicksFrozen(200);
                spawnParticles(attacker, ParticleTypes.SNOWFLAKE, 10);
            }
        }
    }),

    INFERNO_CORE("Inferno Core", 0.0, 5.0, 0.0, 0.0, 0.0, 0.0, new TraitAbility() {
        @Override
        public void onTick(RaceEntity entity) {
            if (entity.tickCount % 20 == 0) {
                List<LivingEntity> nearby = entity.level().getEntitiesOfClass(LivingEntity.class, entity.getBoundingBox().inflate(4.0));
                for (LivingEntity e : nearby) {
                    if (e != entity) e.igniteForSeconds(4);
                }
                spawnParticles(entity, ParticleTypes.FLAME, 5);
            }
        }
    }),

    STORM_BRINGER("Storm Bringer", 0.0, 0.0, 0.0, 2.0, 0.0, 0.0, new TraitAbility() {
        @Override
        public void onAttack(RaceEntity attacker, Entity target) {
            if (attacker.getRandom().nextFloat() < 0.2f && target.level() instanceof ServerLevel sl) {
                LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sl);
                if (bolt != null) {
                    bolt.moveTo(target.position());
                    sl.addFreshEntity(bolt);
                }
            }
        }
    }),

    STATIC_FIELD("Static Field", 0.0, 0.0, 0.1, 0.0, 0.0, 0.0, new TraitAbility() {
        @Override
        public void onHurt(RaceEntity victim, DamageSource source, float amount) {
            if (source.getEntity() instanceof LivingEntity attacker) {
                attacker.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 1));
                attacker.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 10));
                spawnParticles(victim, ParticleTypes.ELECTRIC_SPARK, 10);
            }
        }
    }),

    // ==================================================================================
    // === NEW STATUS SKILLS (Active) ===================================================
    // ==================================================================================

    MIRROR_SKIN("Mirror Skin", 0.0, 0.0, 0.0, 0.0, 10.0, 0.0, new TraitAbility() {
        @Override
        public void onHurt(RaceEntity victim, DamageSource source, float amount) {
            if (source.getEntity() instanceof LivingEntity attacker) {
                attacker.hurt(victim.damageSources().thorns(victim), amount * 0.5f);
                spawnParticles(victim, ParticleTypes.ENCHANTED_HIT, 10);
            }
        }
    }),

    TROLL_BLOOD("Troll Blood", 0.1, 10.0, -0.1, 2.0, 0.0, 0.0, new TraitAbility() {
        @Override
        public void onTick(RaceEntity entity) {
            if (entity.tickCount % 40 == 0 && entity.getHealth() < entity.getMaxHealth()) {
                entity.heal(1.0f);
            }
        }
    }),

    VOLATILE("Volatile", 0.0, -5.0, 0.2, 0.0, 0.0, 0.0, new TraitAbility() {
        @Override
        public void onHurt(RaceEntity victim, DamageSource source, float amount) {
            if (victim.getHealth() - amount <= 0) {
                victim.level().explode(victim, victim.getX(), victim.getY(), victim.getZ(), 3.0f, ServerLevel.ExplosionInteraction.MOB);
            }
        }
    }),

    INTANGIBLE("Intangible", 0.0, -10.0, 0.1, 0.0, 0.0, 0.0, new TraitAbility() {
        @Override
        public void onTick(RaceEntity entity) {
            if (entity.tickCount % 10 == 0) spawnParticles(entity, ParticleTypes.SQUID_INK, 1);
        }
    }),

    ADRENALINE_RUSH("Adrenaline Rush", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, new TraitAbility() {
        @Override
        public void onHurt(RaceEntity victim, DamageSource source, float amount) {
            if (victim.getHealth() < victim.getMaxHealth() * 0.4) {
                victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 2));
                victim.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 100, 1));
            }
        }
    }),

    // ==================================================================================
    // === THE LEGENDARY SKILLS (GOD TIER) ==============================================
    // ==================================================================================

    TITAN_SLAYER("Titan Slayer", 0.5, 100.0, 0.0, 20.0, 15.0, 1.0, new TraitAbility() {
        @Override
        public void onAttack(RaceEntity attacker, Entity target) {
            spawnParticles(attacker, ParticleTypes.SONIC_BOOM, 1);
            attacker.playSound(SoundEvents.WARDEN_SONIC_BOOM, 3.0f, 1.0f);
            target.setDeltaMovement(0, 1.5, 0);

            List<LivingEntity> nearby = attacker.level().getEntitiesOfClass(LivingEntity.class, attacker.getBoundingBox().inflate(6.0));
            for (LivingEntity e : nearby) {
                if (e != attacker && e != target) {
                    e.hurt(attacker.damageSources().mobAttack(attacker), 10.0f);
                    e.push(e.getX() - attacker.getX(), 0.5, e.getZ() - attacker.getZ());
                }
            }
        }
    }),

    CHRONOS_STEP("Chronos Step", 0.0, 50.0, 0.4, 5.0, 5.0, 0.0, new TraitAbility() {
        @Override
        public void onTick(RaceEntity entity) {
            spawnParticles(entity, ParticleTypes.ELECTRIC_SPARK, 2);
            if (entity.tickCount % 5 == 0 && entity.getDeltaMovement().length() > 0.1) {
                entity.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 10, 0, false, false));
            }
        }
        @Override
        public void onAttack(RaceEntity attacker, Entity target) {
            if (target instanceof LivingEntity l) {
                l.hurt(attacker.damageSources().generic(), 6.0f);
                l.hurt(attacker.damageSources().generic(), 6.0f);
            }
        }
    }),

    ARCANE_SOVEREIGN("Arcane Sovereign", 0.0, 80.0, 0.0, 10.0, 10.0, 0.5, new TraitAbility() {
        @Override
        public void onTick(RaceEntity entity) {
            entity.setNoGravity(true);
            if (entity.tickCount % 20 == 0) {
                entity.heal(5.0f);
                List<LivingEntity> nearby = entity.level().getEntitiesOfClass(LivingEntity.class, entity.getBoundingBox().inflate(8.0));
                for (LivingEntity e : nearby) {
                    if (e != entity) {
                        e.addEffect(new MobEffectInstance(MobEffects.WITHER, 40, 2));
                        e.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 10, 0));
                    }
                }
                spawnParticles(entity, ParticleTypes.DRAGON_BREATH, 20);
            }
        }
        @Override
        public void onAttack(RaceEntity attacker, Entity target) {
            attacker.level().explode(attacker, target.getX(), target.getY(), target.getZ(), 2.0f, ServerLevel.ExplosionInteraction.NONE);
        }
    }),

    DEATH_INCARNATE("Death Incarnate", 0.1, 60.0, 0.1, 50.0, 0.0, 0.5, new TraitAbility() {
        @Override
        public void onAttack(RaceEntity attacker, Entity target) {
            spawnParticles(attacker, ParticleTypes.SOUL, 15);
            attacker.playSound(SoundEvents.WITHER_DEATH, 1.0f, 0.5f);
            if (target instanceof LivingEntity living) {
                if (attacker.getRandom().nextFloat() < 0.10f) {
                    living.setHealth(0);
                } else {
                    living.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60));
                    living.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 4));
                }
            }
        }
        @Override
        public void onHurt(RaceEntity victim, DamageSource source, float amount) {
            if (amount > 10.0f) {
                victim.heal(amount - 10.0f);
            }
        }
    }),

    /**
     * LEGENDARY 5: BLADE DANCER
     * The master of speed and precision. Teleports frantically while attacking.
     */
    BLADE_DANCER("Blade Dancer", 0.0, 40.0, 0.6, 25.0, 5.0, 0.0, new TraitAbility() {
        @Override
        public void onAttack(RaceEntity attacker, Entity target) {
            spawnParticles(attacker, ParticleTypes.SWEEP_ATTACK, 5);
            for(int i=0; i<3; i++) {
                double offsetX = (Math.random() - 0.5) * 2.0;
                double offsetZ = (Math.random() - 0.5) * 2.0;
                attacker.teleportTo(target.getX() + offsetX, target.getY(), target.getZ() + offsetZ);
                if (target instanceof LivingEntity l) {
                    l.invulnerableTime = 0;
                    l.hurt(attacker.damageSources().mobAttack(attacker), 5.0f);
                }
            }
        }
    }),

    /**
     * LEGENDARY 6: KENSEI (SWORD SAINT)
     * The master of defense and counter-attacks. Perfect Parry.
     */
    KENSEI("Kensei", 0.0, 60.0, 0.1, 35.0, 15.0, 1.0, new TraitAbility() {
        @Override
        public void onHurt(RaceEntity victim, DamageSource source, float amount) {
            if (victim.getRandom().nextFloat() < 0.5f && source.getEntity() instanceof LivingEntity attacker) {
                victim.playSound(SoundEvents.ANVIL_LAND, 1.0f, 2.0f);
                victim.heal(amount);

                attacker.hurt(victim.damageSources().mobAttack(victim), amount * 3.0f);
                attacker.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 10));
                spawnParticles(victim, ParticleTypes.CRIT, 20);
            }
        }
    }),

    /**
     * LEGENDARY 7: EXECUTIONER
     * The master of one-hit kills.
     */
    EXECUTIONER("Executioner", 0.2, 80.0, -0.2, 50.0, 20.0, 0.8, new TraitAbility() {
        @Override
        public void onAttack(RaceEntity attacker, Entity target) {
            if (target instanceof LivingEntity living) {
                if (living.getHealth() < living.getMaxHealth() * 0.5) {
                    living.hurt(attacker.damageSources().mobAttack(attacker), 9999f);
                    // FIXED: Added .value() specifically here
                    attacker.playSound(SoundEvents.TRIDENT_THUNDER.value(), 1.0f, 0.5f);
                    spawnParticles(target, ParticleTypes.EXPLOSION, 1);
                } else {
                    living.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 3));
                }
            }
        }
    }),

    /**
     * LEGENDARY 8: RONIN
     * The wanderer. Extreme burst damage and armor penetration.
     */
    RONIN("Ronin", 0.0, 50.0, 0.3, 40.0, 0.0, 0.2, new TraitAbility() {
        @Override
        public void onAttack(RaceEntity attacker, Entity target) {
            if (target instanceof LivingEntity living) {
                living.hurt(attacker.damageSources().magic(), 10.0f);
            }
            Vec3 look = attacker.getLookAngle();
            attacker.setDeltaMovement(look.scale(2.0));
            attacker.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 0.5f);
        }
        @Override
        public void onTick(RaceEntity entity) {
            if (entity.tickCount % 20 == 0) entity.heal(2.0f);
        }
    });

    // ==================================================================================
    // === CORE LOGIC ===================================================================
    // ==================================================================================

    private final String displayName;
    private final double scaleMod;
    private final double healthMod;
    private final double speedMod;
    private final double damageMod;
    private final double armorMod;
    private final double knockbackMod;
    private final TraitAbility ability;

    Trait(String name, double scaleMod, double healthMod, double speedMod, double damageMod, double armorMod, double knockbackMod, TraitAbility ability) {
        this.displayName = name;
        this.scaleMod = scaleMod;
        this.healthMod = healthMod;
        this.speedMod = speedMod;
        this.damageMod = damageMod;
        this.armorMod = armorMod;
        this.knockbackMod = knockbackMod;
        this.ability = ability;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void onTick(RaceEntity entity) {
        if (ability != null) ability.onTick(entity);
    }

    public void onAttack(RaceEntity attacker, Entity target) {
        if (ability != null) ability.onAttack(attacker, target);
    }

    public void onHurt(RaceEntity victim, DamageSource source, float amount) {
        if (ability != null) ability.onHurt(victim, source, amount);
    }

    public void apply(RaceEntity entity) {
        applyModifier(entity, Attributes.SCALE, "trait_scale_", scaleMod, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        applyModifier(entity, Attributes.MAX_HEALTH, "trait_health_", healthMod, AttributeModifier.Operation.ADD_VALUE);

        if (healthMod != 0.0) entity.setHealth(entity.getMaxHealth());

        applyModifier(entity, Attributes.MOVEMENT_SPEED, "trait_speed_", speedMod, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        applyModifier(entity, Attributes.ATTACK_DAMAGE, "trait_damage_", damageMod, AttributeModifier.Operation.ADD_VALUE);
        applyModifier(entity, Attributes.ARMOR, "trait_armor_", armorMod, AttributeModifier.Operation.ADD_VALUE);
        applyModifier(entity, Attributes.KNOCKBACK_RESISTANCE, "trait_kb_", knockbackMod, AttributeModifier.Operation.ADD_VALUE);
    }

    private void applyModifier(RaceEntity entity, net.minecraft.core.Holder<net.minecraft.world.entity.ai.attributes.Attribute> attribute, String prefix, double value, AttributeModifier.Operation op) {
        if (value == 0.0) return;
        AttributeInstance instance = entity.getAttribute(attribute);
        if (instance != null) {
            ResourceLocation id = ResourceLocation.fromNamespaceAndPath(ZeroRaces.MODID, prefix + this.name().toLowerCase());
            instance.removeModifier(id);
            instance.addPermanentModifier(new AttributeModifier(id, value, op));
        }
    }

    private static void spawnParticles(Entity e, net.minecraft.core.particles.ParticleOptions p, int count) {
        if (e.level() instanceof ServerLevel level) {
            level.sendParticles(p, e.getX(), e.getY() + e.getBbHeight()/2, e.getZ(), count, 0.5, 0.5, 0.5, 0.1);
        }
    }

    private interface TraitAbility {
        default void onTick(RaceEntity entity) {}
        default void onAttack(RaceEntity attacker, Entity target) {}
        default void onHurt(RaceEntity victim, DamageSource source, float amount) {}
    }
}